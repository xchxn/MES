import os
import re
import shutil
import pandas as pd

PATH_ORIGINAL = './22~24년_1주일단위_엑셀모음'
COLUMNS = ['날짜','관리구분','품목','품종','등급','현재고','현재중량']

original = sorted(os.listdir(PATH_ORIGINAL), key=lambda x: x[-5:]=='xlsx')
df = pd.DataFrame(columns=COLUMNS)

for index, name in enumerate(original):
    temp = pd.read_excel(PATH_ORIGINAL+'/'+name)
    
    # renaming: xlsx to csv
    new_name = re.sub(r'-.+.xlsx', '.csv', name)
    new_name = new_name[:3]+'0'+new_name[3:] \
        if len(new_name)==11 else new_name
    
    # dropping columns
    temp.drop(temp.iloc[:, 12:], axis='columns', inplace=True) # 창고
    temp.drop(temp.iloc[:, 4:10], axis='columns', inplace=True) # 입고, 출고
    temp.drop(temp[temp.iloc[:, 0]=='자재'].index, axis='rows', inplace=True) # 자재
    
    # inserting date column
    temp.insert(0, "날짜", [new_name[:-4]]*len(temp.index), True)

    # changing columns in case of 'X'
    temp.columns = COLUMNS

    # concatenating temp to df
    df = pd.concat([df, temp], ignore_index=True)

# deleting excel folder forcily
# shutil.rmtree(PATH_ORIGINAL, ignore_errors=True)

# creating only-one dataframe and dropping it from df 
df_only_one = df.drop_duplicates(subset=['관리구분','품목','품종','등급'], \
                                 keep=False)
df_final = pd.merge(df, df_only_one, how='outer', indicator=True) \
    .query("_merge=='left_only'").drop(columns=['_merge'])

# sorting by columns
df_final.sort_values(by=['관리구분','품목','품종','등급','날짜'], inplace=True, \
               ignore_index=True)

# creating train.csv, only_one.csv
df_final.to_csv('train.csv')
df_only_one.to_csv('only_one.csv')