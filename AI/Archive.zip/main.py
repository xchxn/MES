from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import numpy as np
import pandas as pd
import tensorflow as tf
from sklearn.preprocessing import MinMaxScaler
import uvicorn

app = FastAPI()

# Load the trained model
model = tf.keras.models.load_model('lstm_model.h5')

# Load the scaler parameters
scaler = MinMaxScaler()
data = pd.read_csv('train.csv')
data['날짜'] = pd.to_datetime(data['날짜'], format='%y.%m.%d')
data.sort_values('날짜', inplace=True)
features = ['현재고', '현재중량']
scaler.fit(data[features])

# Function to create sequences for prediction
def create_sequences(data, seq_length):
    xs = []
    for i in range(len(data) - seq_length):
        x = data[i:i + seq_length]
        xs.append(x)
    return np.array(xs)

class PredictionInput(BaseModel):
    input: list

@app.post("/predict")
async def predict(input_data: PredictionInput):
    try:
        input_df = pd.DataFrame(input_data.input)
        input_scaled = scaler.transform(input_df[features])
        seq_length = 10
        input_sequences = create_sequences(input_scaled, seq_length)

        if len(input_sequences) == 0:
            raise HTTPException(status_code=400, detail="Insufficient input data for sequence creation")

        predictions = model.predict(input_sequences)
        predictions = scaler.inverse_transform(predictions)
        
        response = {
            'predictions': predictions.tolist()
        }
        return response
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == '__main__':
    uvicorn.run(app, host='0.0.0.0', port=8000)
